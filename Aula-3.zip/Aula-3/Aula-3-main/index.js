$(document).ready(
    function(){
        alert("o documento carregou")
    }
)


$('#bt_inicio').click(
function(){
    alert(' Opa,você clicou no botão inicio');
}
)

